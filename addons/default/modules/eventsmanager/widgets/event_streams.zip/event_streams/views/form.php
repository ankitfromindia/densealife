<ol>
	<li class="even">
		<label>Display Limit</label>
		<?php echo form_input('limit', $options['limit']); ?>
	</li>
</ol>