<div class="comman-box clearfix">
    <div class="comman-heading">Messages</div>
    <div class="message-header clearfix">
        <span class="float-left">Inbox({{unread}}) &nbsp;&nbsp;&nbsp;Others(2)</span>
        
        <?php if($action != 'new_message') :?>
        <span class="right">
            <p class="float-left">User Name</p>
            <button>+ New Message</button><button>Action</button>
        </span>
        <?php endif;?>
    </div>
    <div class="all-frineds-messages">
        <ul>
            <?php foreach ( $senders as $sender ):  ?>
                {{user:profile user_id="<?php echo $sender->sender_id; ?>"}}
                <li title="{{display_name}}" class="social-buttons">
                    {{user:profile_pic user_id=user_id}}
                <span class="left-links">
                    <a href="{{username}}">{{display_name}}</a>
                </span>
                </li>
                {{/user:profile}}
            <?php endforeach; ?>
        </ul>
    </div>
    <form method="post" action='/messages/create' id='frm-create-message'>
    <div class="main-message-aera">
        <?php echo $board;?>
        <div class="message-reply-block clearfix">
            <ul class="status">
                <li><span><img src="images/status.png" alt="Status"></span>Update Status</li>
                <li><span><img src="images/addvidoes.png" alt="Vidoes"></span>Add Photos/Video</li>
            </ul>
            <div class="status-box">
                <?php if($action!='new_message'):?>
                    <input type='hidden' name='rec_id' value='<?php echo $rec_id;?>'/>
                    <input type='hidden' name='sender_id'  value='<?php echo $this->current_user->id;?>'/>
                    <?php endif;?>
                    <textarea cols="2" rows="2" name="status" id="status"></textarea>
                    <div class="status-bg"><button class="btn-color post-btn">Reply</button></div>
                
                
            </div>
        </div>
    </div>
        </form>
</div>
<script>
$(function() {
function split( val ) {
return val.split( /,\s*/ );
}
function extractLast( term ) {
return split( term ).pop();
}
$( "#to" )
// don't navigate away from the field on tab when selecting an item
.bind( "keydown", function( event ) {
if ( event.keyCode === $.ui.keyCode.TAB &&
$( this ).data( "ui-autocomplete" ).menu.active ) {
event.preventDefault();
}
})
.autocomplete({
source: function( request, response ) {
$.getJSON( "/messages/search/", {
term: extractLast( request.term )
}, response );
},
search: function() {
// custom minLength
var term = extractLast( this.value );
if ( term.length < 2 ) {
return false;
}
},
focus: function() {
// prevent value inserted on focus
return false;
},
select: function( event, ui ) {
var terms = split( this.value );
// remove the current input
terms.pop();
// add the selected item
terms.push( ui.item.value );
// add placeholder to get the comma-and-space at the end
terms.push( "" );
this.value = terms.join( ", " );
return false;
}
});
});
</script>