<div class='fr' style='width:100%;'>
<div class='fl'><?php echo time_passed(now());?></div>
<div class='fr'><?php echo $pic;?></div>
<div class="arrow_box-right fr mt0 mr20"><?php echo $message;?></div>
<div class='clear'></div>
</div>