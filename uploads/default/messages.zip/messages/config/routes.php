<?php
$route['messages'] = 'messages/index';

