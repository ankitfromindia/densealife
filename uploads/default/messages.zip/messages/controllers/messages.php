<?php

/**
 * @author Ankit Vishwakarma <admin@avsoftechnologies.in>
 * @author Ankit Vishwakarma <ankitvishwakarma@sify.com>
 */
class Messages extends Public_Controller
{
    public function __construct()
    {
        parent::__construct();
//        if ( !is_logged_in() ) {
//            $this->session->set_userdata('redirect_to', current_url());
//            redirect('users/login');
//        }
        $this->template->set_layout('messages');
    }
    
    public function index()
    {
        $this->template->build('messages/index');
    }
    public function create()
    {
        
    }
    public function edit()
    {
        
    }
    public function view()
    {
        
    }
    public function trash()
    {
        
    }
}
