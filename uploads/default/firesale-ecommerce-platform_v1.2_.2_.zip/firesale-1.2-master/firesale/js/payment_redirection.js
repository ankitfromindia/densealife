$(function()
{
	$('#redirect_form').submit();
});