Decimal
=======

The decimal field_type allows you to capture / output decimals to a fixed decimal point with default, max and min params.