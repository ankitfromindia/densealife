<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['streams.decimal.name'] 						= 'Decimale';
$lang['streams.decimal.decimal_places']				= 'Decimale Plaatsen';
$lang['streams.decimal.min_value']					= 'Min Waarde';
$lang['streams.decimal.max_value']					= 'Max Waarde';

// Errors
$lang['streams.decimal.error.min_value']			= 'De %s inhoud is onder het minimaal toegestaande waarde.';
$lang['streams.decimal.error.max_value']			= 'De %s inhoud is boven het maximaal toegestaande waarde.';
