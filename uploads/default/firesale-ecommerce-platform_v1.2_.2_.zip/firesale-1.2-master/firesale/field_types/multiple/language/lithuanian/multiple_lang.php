<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['streams:multiple.name'] 		= 'Sąryšiai (daug)';
$lang['streams:multiple.choose_stream'] = 'Srautas sąryšiui';
$lang['streams:multiple.choose_ui']     = 'Choose UI'; #translate
$lang['streams:multiple.drag_drop']     = 'Drag/Drop'; #translate
$lang['streams:multiple.multiselect']   = 'Multiselect'; #translate
$lang['streams:multiple.no_change']     = 'You cannot change a multiple relationship field stream once it has been assigned.'; #translate
