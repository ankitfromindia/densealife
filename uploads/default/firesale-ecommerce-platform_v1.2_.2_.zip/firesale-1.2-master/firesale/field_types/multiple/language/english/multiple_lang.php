<?php defined('BASEPATH') or exit('No direct script access allowed');

$lang['streams:multiple.name'] 			= 'Multiple Relationships';
$lang['streams:multiple.choose_stream'] = 'Relationship Stream';
$lang['streams:multiple.choose_ui']     = 'Choose UI';
$lang['streams:multiple.drag_drop']     = 'Drag/Drop';
$lang['streams:multiple.multiselect']   = 'Multiselect';
$lang['streams:multiple.no_change']     = 'You cannot change a multiple relationship field stream once it has been assigned.';
