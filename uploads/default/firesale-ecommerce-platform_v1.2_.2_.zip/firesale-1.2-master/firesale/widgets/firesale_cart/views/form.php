<ol>
    <li class="even">
        <label>Hide when empty?</label>
        <?php echo form_dropdown('hide', $hide, $options['hide']); ?>
    </li>
</ol>
