<ol>
    <li class="even">
        <label>Parent Category</label>
        <?php echo form_dropdown('parent', $categories, $options['parent']); ?>
    </li>
</ol>
