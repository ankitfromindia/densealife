<?php echo form_open(); ?>
    <p>Payment processing is done on the WorldPay website, so if you're happy with everything please click below to finalise your order!</p>
    <button type="submit" class="btn"><span>Pay with WorldPay</span></button>
<?php echo form_close();
