<?php echo form_open(); ?>
    <p>Payment processing is done on the GoCardless website, so if you're happy with everything please click below to finalise your order!</p>
    <button type="submit" class="btn"><span>Pay with GoCardless</span></button>
<?php echo form_close();
