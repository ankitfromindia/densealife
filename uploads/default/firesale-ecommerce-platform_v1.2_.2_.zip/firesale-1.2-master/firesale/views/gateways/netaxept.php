<?php echo form_open(); ?>
    <p>Payment processing is done on the Netaxept website, so if you're happy with everything please click below to finalise your order!</p>
    <button type="submit" class="btn"><span>Pay with Netaxept</span></button>
<?php echo form_close();
