<?php echo form_open(); ?>
    <p>Payment processing is done on the AuthorizeNet website, so if you're happy with everything please click below to finalise your order!</p>
    <button type="submit" class="btn"><span>Pay with AuthorizeNet</span></button>
<?php echo form_close();
