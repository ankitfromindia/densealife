<h2><?php echo lang('firesale:payment:cancelled'); ?></h2>
