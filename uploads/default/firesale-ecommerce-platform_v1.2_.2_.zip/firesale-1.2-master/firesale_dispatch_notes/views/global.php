<!doctype html>
<html>
<head>
	<title>Dispatch Note(s)</title>
	<meta charset="utf-8" />
	<meta name="robots" content="noindex" />
	{{ template:metadata }}
</head>

<body bgcolor="#FFFFFF" onload="window.print();">
	<?php echo $content; ?>
</body>
</html>