<?php defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Trends library
 *
 * @author		Phil Sturgeon
 * @author		PyroCMS Dev Team
 * @package		PyroCMS\Core\Modules\Trends\Libraries
 */

class Trends
{
	/**
	 * The name of the module in use
	 * 
	 * @var	string
	 */
	protected $module;

	/**
	 * Singular language key
	 * 
	 * @var	string
	 */
	protected $singular;

	/**
	 * Plural language key
	 * 
	 * @var	string
	 */
	protected $plural;

	/**
	 * Entry for this, be it an auto increment id or string
	 * 
	 * @var	string|int
	 */
	protected $entry_id;

	/**
	 * Title of the entry
	 * 
	 * @var	string
	 */
	protected $entry_title;

	/**
	 * What is the URL of this entry?
	 * 
	 * @var	string
	 */
	protected $entry_uri;

	/**
	 * Encrypted hash containing title, singular and plural keys
	 * 
	 * @var	bool
	 */
	protected $entry_hash;

	/**
	 * Comment Count
	 *
	 * Setting to 0 by default.
	 *
	 * @var 	int
	 */
	protected $count = 0;
        
        CONST TREND_FOLLOW  = 1; 
        CONST TREND_FAVOURITE = 2;
        CONST TREND_STAR = 3; 

        /**
	 * Function to display a trend
	 *
	 * Reference is a actually an object reference, a.k.a. categorization of the trends table rows.
	 * The reference id is a further categorization on this. (For example, for example for
	 *
	 * @param	string	$module		The name of the module in use
	 * @param	string	$singular	Singular language key
	 * @param	string	$plural		Plural language key
	 * @param	string|int	$entry_id	Entry for this, be it an auto increment id or string, or null
	 */
	public function __construct($params)
	{
		ci()->load->model('trends/trend_m');
		ci()->lang->load('trends/trends');

		// This shouldnt be required if static loading was possible, but its not in CI
		if (is_array($params))
		{
			// Required
			$this->module = $params['module'];
			$this->singular = $params['singular'];
			$this->plural = $params['plural'];

			// Overridable
			$this->entry_uri = isset($params['uri']) ? $params['uri'] : uri_string();

			// Optional
			isset($params['entry_id']) and $this->entry_id = $params['entry_id'];
			isset($params['entry_title']) and $this->entry_title = $params['entry_title'];
		}
	}
	
	/**
	 * Display trends
	 *
	 * @return	string	Returns the HTML for any existing trends
	 */
	public function display()
	{
		// Fetch trends, then process them
		$trends = $this->process(ci()->trend_m->get_by_entry($this->module, $this->singular, $this->entry_id));
		// Return the awesome trends view
		return $this->load_view('display', compact(array('trends')));
	}
        
        public function display_children($parent_id = null)
	{
		// Fetch trends, then process them
		$trends = $this->process(ci()->trend_m->get_by_entry($this->module, $this->singular, $this->entry_id, true, $parent_id));
		// Return the awesome trends view
		return $this->load_view('display_children', compact(array('trends')));
	}
       
        public function feeds($limit = null)
	{
		// Fetch trends, then process them
		return $this->process(ci()->trend_m->get_recent($limit));
		
	}

	
	/**
	 * Display form
	 *
	 * @return	string	Returns the HTML for the trend submission form
	 */
	public function form()
	{
		// Return the awesome trends view
		return $this->load_view('form', array(
			'module'        =>  $this->module,
			'entry_hash'    =>  $this->encode_entry(),
			'trend'         =>  ci()->session->flashdata('trend')
		));
	}
        
        public function follow()
	{
		// Return the awesome trends view
		return $this->load_view('follow', array(
			'module'        =>  $this->module,
			'entry_hash'    =>  $this->encode_entry(),
			'trend'         =>  ci()->session->flashdata('trend'),
                        'is_following'  => $this->count(self::TREND_FOLLOW, ci()->current_user->id)
		));
	}

        public function favorite()
	{
		// Return the awesome trends view
		return $this->load_view('favorite', array(
			'module'        =>  $this->module,
			'entry_hash'    =>  $this->encode_entry(),
			'trend'         =>  ci()->session->flashdata('trend'),
                        'is_following'  => $this->count(self::TREND_FAVOURITE, ci()->current_user->id)
		));
	}
        
        public function star($display_count = false)
	{
		// Return the awesome trends view
		return $this->load_view('star', array(
			'module'        =>  $this->module,
			'entry_hash'    =>  $this->encode_entry(),
			'trend'         =>  ci()->session->flashdata('trend'),
                        'is_following'  => $this->count(self::TREND_STAR, ci()->current_user->id),
                        'display'       => $display_count 
		));
	}
        
        public function display_stars(){
            return $this->load_view('display_stars', array(
                        'count'  => $this->count(self::TREND_STAR)
		));
        }
	/**
	 * Count trends
	 *
	 * @return	int	Return the number of trends for this entry item
	 */
	public function count($trend, $user_id=null)
	{
           $where =  array(
			'module'	=> $this->module,
			'entry_key'	=> $this->singular,
                        'trend'         => $trend
		);
           if(!is_null($this->entry_id)){
               $where['entry_id'] = $this->entry_id;
           }
           if(!is_null($user_id)){
               $where['user_id'] = $user_id;
           }
           ci()->db->where($where)->count_all_results('trends');
		return (int) ci()->db->where($where)->count_all_results('trends');
	}
        
        public function count_new($trend)
	{
           $where =  array(
			'module'	=> $this->module,
			'entry_key'	=> $this->singular,
			'entry_id'	=> $this->entry_id,
                        'trend'         => $trend, 
                        'DATEDIFF( NOW( ) , created_on ) <=' =>7
		);
          
		return (int) ci()->db->where($where)->count_all_results('trends');
	}

	/**
	 * Count trends as string
	 *
	 * @return	string 	Language string with the total in it
	 */
	public function count_string($trend_count = null)
	{
		$total = ($trend_count) ? $trend_count : $this->count;

		switch ($total)
		{
			case 0:
				$line = 'none';
				break;
			case 1:
				$line = 'singular';
				break;
			default:
				$line = 'plural';
		}

		return sprintf(lang('trends:counter_'.$line.'_label'), $total);
	}

	/**
	 * Function to process the items in an X amount of trends
	 *
	 * @param array $trends The trends to process
	 * @return array
	 */
	public function process($trends)
	{
		// Remember which modules have been loaded
		static $modules = array();

		foreach ($trends as &$trend)
		{
			// Override specified website if they are a user
			if ($trend->user_id and Settings::get('enable_profiles'))
			{
				$trend->website = 'user/'.$trend->user_name;
			}

			// We only want to load a lang file once
			if ( ! isset($modules[$trend->module]))
			{
				if (ci()->module_m->exists($trend->module))
				{
					ci()->lang->load("{$trend->module}/{$trend->module}");

					$modules[$trend->module] = true;
				}
				// If module doesn't exist (for whatever reason) then sssh!
				else
				{
					$modules[$trend->module] = false;
				}
			}

			$trend->singular = lang($trend->entry_key) ? lang($trend->entry_key) : humanize($trend->entry_key);
			$trend->plural = lang($trend->entry_plural) ? lang($trend->entry_plural) : humanize($trend->entry_plural);

			// work out who did the trending
			if ($trend->user_id > 0)
			{
				$trend->user_name = anchor('admin/users/edit/'.$trend->user_id, $trend->user_name);
			}

			// Security: Escape any Lex tags
			foreach ($trend as $field => $value)
			{
				$trend->{$field} = escape_tags($value);
			}
		}
		
		return $trends;
	}

	/**
	 * Load View
	 *
	 * @return	string	HTML of the trends and form
	 */
	protected function load_view($view, $data)
	{
		$ext = pathinfo($view, PATHINFO_EXTENSION) ? '' : '.php';
		
		if (file_exists(ci()->template->get_views_path().'modules/trends/'.$view.$ext))
		{
			// look in the theme for overloaded views
			$path = ci()->template->get_views_path().'modules/trends/';
		}
		else
		{
			// or look in the module
			list($path, $view) = Modules::find($view, 'trends', 'views/');
		}
		
		// add this view location to the array
		ci()->load->set_view_path($path);
		ci()->load->vars($data);

		return ci()->load->_ci_load(array('_ci_view' => $view, '_ci_return' => true));
	}

	/**
	 * Encode Entry
	 *
	 * @return	string	Return a hash of entry details, so we can send it via a form safely.
	 */
	protected function encode_entry()
	{
		return ci()->encrypt->encode(serialize(array(
			'id'			=>	$this->entry_id,
			'title'			=> 	$this->entry_title,
			'uri'			=>	$this->entry_uri,
			'singular'		=>	$this->singular,
			'plural'		=>	$this->plural,
		)));
	}
        
        
    public function get_popular_entry($limit = null)
    {
        ci()->db->select('e.*, count(trend) as trend')
                ->from('events as e')
                ->join('trends as et', 'et.entry_id = e.id', 'left')
                ->where('e.published', 1)
                ->group_by('e.slug')
                ->order_by('et.trend', 'DESC')
                ->order_by('e.title', 'ASC') ;
        if ( !is_null($limit) ) {
            ci()->db->limit($limit) ;
        }
        return ci()->db->get()
                        ->result() ;
    }

}