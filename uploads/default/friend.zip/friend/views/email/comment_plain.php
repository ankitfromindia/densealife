You have received an email from {{ name }}

IP Address: {{ sender_ip }
Operating System: {{ sender_os }
User Agent: {{ sender_agent }

{{ comment }