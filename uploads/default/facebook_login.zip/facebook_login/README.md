# Module Facebook Login

#Team

* [website](http://www.pyrocms.fr)
* [PyroCMS France on Twitter](https://twitter.com/PyroCMS_France)
* [Khalil TABBAL](http://www.khalil-tabbal.com)
* Geoffrey Monté

## Description

This module allow you (at least try to ;) ) Log your users using Facebook.
It's the first version, so please be nice with us !
You also could fork it, customize it and make pull request as it's open sourced.
We are like that, and we hope you will enrich this module as fast as Facebook change his API =) 

It is an initiative from PyroCMS France Community, so if you want to thanks Khalil for his work, you could contact him here : http://www.pyrocms.fr/contact

We strongly hope to hear you about thing an others :)

##Installation

First of all you need to download the Facebook-SDK spark available :

on Github https://github.com/joeyblake/Facebook-SDK-Spark
on getsparks.com http://getsparks.org/static/archives/Facebook-SDK/Facebook-SDK-0.0.1.zip

Facebook sdk should be installed in the following folder :
system/sparks/facebook-sdk/0.0.1

The control in details is case sensitive !!!

# Licence

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the License. You may obtain a copy of the License at

http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
