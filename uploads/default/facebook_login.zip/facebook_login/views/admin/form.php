<section class="title">
	<!-- We'll use $this->method to switch between login.create & login.edit -->
	<h4><?php echo lang('login:'.$this->method); ?></h4>
</section>

<section class="item">

	

</section>