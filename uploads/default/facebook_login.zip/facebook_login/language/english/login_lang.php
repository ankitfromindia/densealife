<?php
//messages
$lang['login:success']			=	'It worked';
$lang['login:error']			=	'It didn\'t work';
$lang['login:no_items']		=	'No Items';

//page titles
$lang['login:create']			=	'Create Item';

//labels
$lang['login:name']			=	'Name';
$lang['login:slug']			=	'Slug';
$lang['login:manage']			=	'Manage';
$lang['login:item_list']		=	'Item List';
$lang['login:view']			=	'View';
$lang['login:edit']			=	'Edit';
$lang['login:delete']			=	'Delete';

//buttons
$lang['login:custom_button']	=	'Custom Button';
$lang['login:items']			=	'Items';
?>