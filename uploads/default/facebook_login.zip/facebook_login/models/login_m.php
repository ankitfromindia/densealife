<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
/**
 * This is a login module for PyroCMS
 *
 * @author              Khalil TABBAL
 * @author              NOVIRIS DEV TEAM
 * @link                http://www.noviris.com
 * @package             NOVIRIS
 * @subpackage          LOGIN
 */
class login_m extends MY_Model {

	public function __construct()
	{		
		parent::__construct();
	}
        
        // TODO : not useful for the moment
	
}
