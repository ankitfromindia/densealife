<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Page extends Public_Controller
{

    public function __construct()
    {
        parent::__construct();
        if ( !is_logged_in() ) {
            $this->session->set_userdata('redirect_to', current_url());
            redirect('users/login');
        }
        $this->load->library('comments/comments');
        $this->template->set_layout('wall')->append_js('wall.js');
    }

    public function index()
    {
        $this->template
                ->set('content', $this->load_view('page/activity'))
                ->build('page/index');
    }
    
    public function events()
    {
        $this->template
                ->set('content', $this->load_view('page/events'))
                ->build('page/index');
    }
    

    protected function load_view($view, $data = null)
    {
        $ext = pathinfo($view, PATHINFO_EXTENSION) ? '' : '.php'; 

        if ( file_exists($this->template->get_views_path() . 'modules/profile/' . $view . $ext) ) {
            // look in the theme for overloaded views
            $path = $this->template->get_views_path() . 'modules/profile/';
        } else {
            // or look in the module
            list($path, $view) = Modules::find($view, 'profile', 'views/');
        }

        // add this view location to the array
        $this->load->set_view_path($path);
        $this->load->vars($data);

        return $this->load->_ci_load(array( '_ci_view' => $view, '_ci_return' => true ));
    }

}
