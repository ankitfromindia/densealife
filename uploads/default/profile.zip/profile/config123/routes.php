<?php

if ( !defined('BASEPATH') ) exit('No direct script access allowed') ;

$route['page'] = 'page/index' ;
$route['page/activity'] = 'page/activity' ;