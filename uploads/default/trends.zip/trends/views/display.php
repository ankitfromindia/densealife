<?php 
echo 'hello'; 