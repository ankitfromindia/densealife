# Olark Live Chat

Olark live chat module for PyroCMS and FireSale (v1.2.1 or greater if installed).

## Description

Live chat with visitors to your site with Olark from your existing IM client. A simple, easy to use solution that only takes a few minutes to setup. Syncs visitor data (email, name and phone number) to let you know which user your chatting to if they're logged. 

Integration with FireSale with the following features and benefits:
 - See what customers put in their carts live (cart sync)
 - Receive notifications on important events such as when a customer begins the checkout process or has a cart total over a specific threshold (an important customer)
 - Give VIP service to your most valuable shoppers
 - Help many customers at once
 - Stop abandoned carts
 - Receive notifications when users apply discount codes to their cart. (requires FireSale Discount Codes)

(FireSale install detection is automatic, additional settings appear in the Olark tab if or when FireSale is installed

## Installation

* Signup for a free account at [olark.com](http://www.olark.com/?r=4eqdhi13) (or one of their packages if you want additional features)
* Edit your extensions and preferences such as appearance. There's plenty of customization to check out.
* grab your Site ID from here https://www.olark.com/settings/code.
* Install the Olark module found in the .zip
* Paste your Olark Site ID into the Olark Site ID field (found on the settings page under the Olark tab). You can choose to include the live chat feature on the front and/or back end.

## Extras

The Olark beta chat client comes with some great features/commands for chat operators.

Some details on commands can be found [here](http://www.olark.com/customer/portal/articles/372368-olark-commands)

Examples:
* Insert a product directly into a customers cart by typing !push http://www.YOURDOMAINNAME/cart/insert/PRODUCTID/QUANTITY whilst talking to them.
They will be redirected to the cart. All you need to know is the product id (and quantity if required)
* Enable beta features from the Olark Hatchery (https://www.olark.com/hatchery) such as operator avatars and the !see command
When talking to a user type !see You will be able to see what the visitor sees (including page changes). Clicking will highlight a point of interest, this is great if you want to draw attention to or explain something to the visitor.
