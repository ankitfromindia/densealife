<ol>
    <li class="odd">
        <label>ID</label>
        <?php echo form_input('id', $options['id']); ?>
    </li>
    <li class="even">
        <label>Folder path</label>
        <?php echo form_input('folder', $options['folder']); ?>
    </li>
</ol>