<?php

class Message_m extends MY_Model{
    
    protected $_table = 'messages';
    
    public function __construct()
    {
        parent::__construct();
        
    }
    
    public function insert($data, $skip_validation = false)
    {
        parent::insert($data, $skip_validation);
    }
    
    public function update($primary_value, $data, $skip_validation = false)
    {
        parent::update($primary_value, $data, $skip_validation);
    }
    
    public function delete($id)
    {
        parent::delete($id);
    }
}