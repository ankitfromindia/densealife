<?php

/**
 * @author Ankit Vishwakarma <admin@avsoftechnologies.in>
 * @author Ankit Vishwakarma <ankitvishwakarma@sify.com>
 */
class Message extends Public_Controller
{
    public function __construct()
    {
        parent::__construct();
    }
    
    public function index()
    {
        
    }
    public function create()
    {
        
    }
    public function edit()
    {
        
    }
    public function view()
    {
        
    }
    public function trash()
    {
        
    }
}
