<?php

class OAuth_Token_Access extends OAuth_Token {

	protected $name = 'access';

} // End OAuth_Token_Access