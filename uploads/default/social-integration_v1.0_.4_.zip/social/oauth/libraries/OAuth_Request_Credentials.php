<?php

class OAuth_Request_Credentials extends OAuth_Request {


} // End OAuth_Request_Credentials
